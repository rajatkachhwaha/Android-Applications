package com.example.rjt.baseballcards;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
//import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button search;
    private EditText date;
    private EditText grade;
    private EditText team;
    private EditText name;
    String fields;
    boolean chck;
    boolean andCheck;


    // private Button buy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = (Button) findViewById(R.id.search);
        date = (EditText) findViewById(R.id.date);
        grade = (EditText) findViewById(R.id.gradetype);
        team = (EditText) findViewById(R.id.team);
        name = (EditText) findViewById(R.id.name);

        chck = true;
        andCheck = false;
        //buy=(Button)findViewById(R.id.buy);
        search.setOnClickListener(this);
    }


    public void onClick(View v) {

        String and = "";

        String query = "SELECT rowid _id,* from card_detail WHERE ";

        if (v == search) {


            //String fquery;
            if (date.getText().toString().length() > 0) {
                fields = date.getText().toString();
                query = query.concat(and + "crd_dt =\"" + fields + "\" ");
                   and = "AND ";


            }
            if (grade.getText().toString().length() > 0) {
                fields = grade.getText().toString();
                query = query.concat(and + "condition =\"" + fields + "\" ");
                   and = "AND ";

            }
            if (team.getText().toString().length() > 0) {

                fields = team.getText().toString();
                query = query.concat(and + "team =\"" + fields + "\" ");
                   and = "AND ";

            }
            if (name.getText().toString().length() > 0) {

                fields = name.getText().toString();
                query = query.concat(and + "name =\"" + fields + "\" ");
                    and = "AND ";

            }
        } else {
            chck = false;
            Toast.makeText(MainActivity.this, "Please enter the values",
                    Toast.LENGTH_LONG).show();
        }


        if (chck) {
            Intent inti = new Intent(MainActivity.this, searchresult.class);

            inti.putExtra("query", query);
            startActivity(inti);


        }


    }

}


